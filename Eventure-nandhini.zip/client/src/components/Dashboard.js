import React from 'react';
import { Link } from 'react-router-dom';

const Dashboard = () => {
  return (
    <div>
      <h1>Welcome to Eventure</h1>
      <div>
        <h2>Upcoming Events</h2>
        <p><Link to="/event/1">Conference on Web Development</Link> - Date: 2024-02-15</p>
        <p><Link to="/event/2">Tech Networking Meetup</Link> - Date: 2024-03-05</p>
      </div>
      <Link to="/create">
        <button>Create New Event</button>
      </Link>
    </div>
  );
};

export default Dashboard;
