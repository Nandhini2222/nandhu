import React from 'react';
import { useParams } from 'react-router-dom';

const EventDetails = () => {
  let { id } = useParams();

  return (
    <div>
      <h1>Event Details (Event ID: {id})</h1>
      <p>Event Name: Conference on Web Development</p>
      <p>Date: 2024-02-15</p>
      <p>Location: Techville Convention Center</p>
      <p>Description: This conference will cover various aspects of web development...</p>
      <p>Participants: John Doe, Jane Smith, Alex Johnson</p>
    </div>
  );
};

export default EventDetails;
